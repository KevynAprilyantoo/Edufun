-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2024 at 03:30 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edufun`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Data Science', 'data-science', '2024-11-07 06:23:46', '2024-11-07 06:23:46'),
(2, 'Network Security', 'network security', '2024-11-07 06:23:46', '2024-11-07 06:23:46');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2024_11_05_153452_create_categories_table', 1),
(2, '2024_11_05_163929_create_writers_table', 1),
(3, '2024_11_05_165146_create_posts_table', 1),
(4, '2024_11_06_031535_create_sessions_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `short_description` text NOT NULL,
  `content` text NOT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `published_date` date DEFAULT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `writer_id` bigint(20) UNSIGNED NOT NULL,
  `is_popular` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `slug`, `short_description`, `content`, `thumbnail`, `published_date`, `category_id`, `writer_id`, `is_popular`, `created_at`, `updated_at`) VALUES
(1, 'Machine Learning', 'machine-learning', 'Sed quia iste ut id sunt. Praesentium harum et esse ea necessitatibus rerum eos. Ipsum consequatur nobis veritatis iste. Qui incidunt qui corporis ut nihil.', 'Quia qui et eligendi laboriosam voluptate. Doloribus nostrum amet et sapiente. Sit nulla modi repellendus suscipit.\n\nOmnis consequatur quo laboriosam non veniam qui. Voluptates odio unde debitis non minima neque. Beatae non iure tempore. Ex dolores quia in voluptatem architecto.\n\nIncidunt velit vitae laborum vero eum corrupti. Laudantium voluptatem dolorem nemo sed amet error. Ut rerum aut et veritatis blanditiis. Debitis perferendis aperiam molestias beatae.\n\nBlanditiis ipsum totam nulla voluptatem. Iure omnis perferendis ipsa mollitia. Aut ipsam exercitationem sequi magni sit explicabo.\n\nAccusamus ut quam consequatur quae qui. Quasi recusandae quia a nisi est. Sit minus totam ut mollitia aut placeat veritatis. Delectus ex explicabo mollitia illo. Laboriosam facere vero sunt aspernatur est earum.', 'images/machine.jpg', '2024-08-28', 1, 1, 1, '2024-11-07 06:23:46', '2024-11-07 06:23:46'),
(2, 'Deep Learning', 'deep-learning', 'Dolor qui natus accusamus corporis consectetur rem. Explicabo dolorem quasi suscipit consequuntur. Autem non et fuga non.', 'Iste excepturi voluptatum incidunt enim. Alias aliquid quas quia quo nisi voluptatem dolores. Qui maiores libero quae quae nostrum. Quia dignissimos commodi est.\n\nQuae voluptates rem nesciunt fugiat eum. Qui in delectus dolorum aut est voluptatum. Sunt consequatur omnis sint laboriosam sapiente officia neque.\n\nUt ab debitis odit quisquam quas. Deleniti sit commodi cupiditate cupiditate pariatur non. Quas ipsa sint ad sed nemo.\n\nEst rerum id est nostrum ratione. Sit eligendi ut animi et nesciunt eum. Tenetur excepturi consequatur enim et molestiae eum omnis corporis. Eius rem ut similique ab quasi. Harum nihil reprehenderit rerum facere veritatis aspernatur saepe.\n\nRatione qui nemo officia omnis dolorum eos accusamus. Ratione aperiam dolores velit. Ducimus temporibus et sed eius ut perferendis.', 'images/deep.jpeg', '2024-04-03', 1, 2, 1, '2024-11-07 06:23:46', '2024-11-07 06:23:46'),
(3, 'Natural Language Processing', 'nlp', 'Nulla eos minima aut eum. Soluta accusantium laborum nam molestiae magnam et.', 'Aut voluptates similique ea ipsam quia repellat. Atque debitis nihil reprehenderit. Veritatis consequatur mollitia voluptas dignissimos ut sed rerum.\n\nRem nostrum et amet dicta consequatur soluta assumenda. Vel officia illo exercitationem nisi voluptas. Consequatur praesentium molestiae eligendi quibusdam omnis.\n\nMinus vel modi eos quo sit et. Et libero dolor corporis sit aut aperiam veritatis.\n\nNulla dolor deserunt aut voluptatibus quibusdam accusamus. Similique et dolor veritatis. Eius debitis sequi et. Sequi illo tenetur nisi ipsam maxime incidunt.\n\nDicta et qui qui hic. Distinctio porro eum odio aut.', 'images/nlp.jpg', '2024-06-17', 1, 2, 1, '2024-11-07 06:23:46', '2024-11-07 06:23:46'),
(4, 'Fundamental Network Security', 'fundamental-network-security', 'Voluptate quia numquam et qui hic eveniet quos. Ullam dolores enim explicabo laborum vel.', 'Eum laborum dolorum sit et repudiandae voluptatem harum perferendis. Quod incidunt iusto ducimus. Eveniet qui iusto eum repellendus rerum dolorem voluptates. Commodi enim et consequuntur voluptatum expedita consequatur animi.\n\nConsequuntur sint excepturi ex unde. Voluptatum facilis atque quis. Sed saepe vel earum rem nostrum.\n\nAb aperiam tempora unde alias perferendis. Excepturi autem et consequuntur voluptatem atque. Est consequatur corrupti rerum corporis. Molestiae distinctio placeat iste.\n\nEst laboriosam veniam aut id velit harum et. Ut suscipit aut debitis nemo.\n\nDolores accusamus velit quibusdam similique sunt. Voluptas qui corrupti nostrum voluptatem. Consectetur autem provident cumque consectetur voluptatum.', 'images/net-security.jpeg', '2024-04-26', 2, 1, 1, '2024-11-07 06:23:46', '2024-11-07 06:23:46'),
(5, 'Cloud Computing', 'cloud-computing', 'Excepturi quia veniam quisquam consequatur repellendus enim. Et omnis qui in vitae voluptatibus. Qui est suscipit rerum sint ratione deleniti eum.', 'Assumenda dicta ducimus cum consectetur delectus voluptates ut. Repellat voluptatibus debitis beatae molestiae dolore voluptas. Repellendus magnam est voluptatem eos iusto veritatis distinctio dolorum. Et labore similique sed voluptatem fugit voluptatibus.\n\nDolor cumque eos et quaerat quia. Iste velit tempora praesentium est tenetur at blanditiis. Nulla necessitatibus distinctio non dolor. Dolore qui enim quae dolor mollitia dolorem.\n\nEt ut harum sit tenetur. Est aut sed aut qui ullam. Omnis iure doloribus sunt quasi.\n\nNisi autem quaerat quam nemo quia ut voluptatum. Ipsum sequi eos laboriosam deleniti nobis aut. Labore qui magni minus corrupti ullam et ut sunt.\n\nRem nostrum sint ipsa sunt quia eos. Numquam quisquam consectetur consequatur enim rerum qui totam. Harum doloremque perferendis sunt vel consequatur facere eaque dolorem. Esse qui hic aut necessitatibus. Ratione quis placeat iusto ut.', 'images/cloud.png', '2024-05-11', 2, 3, 1, '2024-11-07 06:23:46', '2024-11-07 06:23:46'),
(6, 'Network Administration', 'network-administration', 'Non voluptatem est laborum cum soluta autem. Non qui nesciunt maiores natus fugiat ipsa reprehenderit. Ut fugiat ducimus repudiandae natus. Quia et nam inventore nihil itaque id.', 'Aut aut perspiciatis rerum tempore non occaecati delectus. Eligendi quis atque eligendi aliquam sit tempora. Eaque praesentium vitae qui quia voluptas asperiores minima.\n\nQuia eos aut voluptas exercitationem totam sit fugiat. Sint et quo est ut. Vel omnis fugit omnis consequuntur ipsam ex.\n\nFugiat et voluptates qui quia aut voluptas. Eligendi ab vitae sed ducimus quae. Autem eius asperiores odio aut.\n\nAssumenda laboriosam labore facere quasi dolore cupiditate. Non veritatis nemo sed quo sapiente beatae. Sit consequatur odit veniam reiciendis. Eligendi libero necessitatibus alias rerum architecto.\n\nFacilis nisi nulla accusantium est tenetur nostrum. Assumenda illum nam ea eaque. Voluptate sint id voluptas ut consequatur.', 'images/net-adm.jpg', '2024-05-02', 2, 3, 1, '2024-11-07 06:23:46', '2024-11-07 06:23:46');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` text NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('TnS8Lgm0m9JropWmqAadKefNbOjzaqvD7wi2VFEU', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY2hJMlFzdnpEdFpJNVpaWkJyYXd4RmR3QVRkUzFOemtaZTkwSG41QSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730989151);

-- --------------------------------------------------------

--
-- Table structure for table `writers`
--

CREATE TABLE `writers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `specialization` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `writers`
--

INSERT INTO `writers` (`id`, `name`, `specialization`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Raka Putra Wicaksono', 'Spesialis Interactive Multimedia', 'images/prof1.jpeg', '2024-11-07 06:23:46', '2024-11-07 06:23:46'),
(2, 'Bia Mecca Annisa', 'Spesialis Data Science', 'images/prof2.jpeg', '2024-11-07 06:23:46', '2024-11-07 06:23:46'),
(3, 'Abi Firmansyah', 'Spesialis Network Security', 'images/prof3.jpeg', '2024-11-07 06:23:46', '2024-11-07 06:23:46');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `posts_slug_unique` (`slug`),
  ADD KEY `posts_category_id_foreign` (`category_id`),
  ADD KEY `posts_writer_id_foreign` (`writer_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `writers`
--
ALTER TABLE `writers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `writers`
--
ALTER TABLE `writers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `posts_writer_id_foreign` FOREIGN KEY (`writer_id`) REFERENCES `writers` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
