

<?php $__env->startSection('title'); ?>
<title>Category</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="container-fluid" >
        <?php if(isset($category)): ?>
            <h2 class="mt-4 ml-3" style="font-size: 30px; font-weight: bold;"><?php echo e($category->name); ?></h2>
            <div class="row pt-2 g-5 m-0">
                <?php $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4">
                        <img src="<?php echo e(asset($module->thumbnail)); ?>" alt="content" class="img-fluid w-100" style="border-radius: 60px; max-height: 300px; height: auto; margin-left: 20px; object-fit: cover; " >
                    </div>
                    <div class="col-lg-8 pt-3" style="padding-left = 10px">
                        <h3 class="larger_text"><?php echo e($module->title); ?></h1>
                            <p class="text-muted">
                                <?php echo e(\Carbon\Carbon::parse($module->published_date)->format('d M Y') . ' | ' . $module->writer->name . ''); ?></p>
                            <p class="larger_text text-truncate"  style="display: -webkit-box; -webkit-box-orient: vertical; overflow: hidden; text-overflow: ellipsis;">
                                <?php echo e($module->short_description); ?>

                            </p>
                            <a href="<?php echo e(route('module', $module->slug)); ?>" class="btn btn-dark px-5 rounded-5 float-end" style="border-radius: 40px;">Read more...</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\UTS-2602089793\resources\views/category.blade.php ENDPATH**/ ?>