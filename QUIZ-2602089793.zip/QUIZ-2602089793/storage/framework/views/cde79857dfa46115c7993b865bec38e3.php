<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->yieldContent('title'); ?>
    <link rel="stylesheet" href="<?php echo e(asset ('bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset ('css/style.css')); ?>">

</head>
<body class="" style="background-color: #a1aca1;">

    <div class="d-flex flex-column min-vh-100">
        <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <main class="flex-grow-1">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

</body>

</html><?php /**PATH C:\Users\admin\UTS-2602089793\resources\views/components/master.blade.php ENDPATH**/ ?>