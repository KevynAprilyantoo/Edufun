

<?php $__env->startSection('title'); ?>
<title>Home</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12">
    <img src=<?php echo e(asset ('images/home.jpg')); ?> class="gambar1">
  </div>

  <div class="container-fluid">
    <div class="row py-4 g-5 m-0">
        <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-5">
                <img src="<?php echo e(url($module->thumbnail)); ?>" alt="content" class="img-fluid w-100 rounded-10" style="border-radius: 60px; max-height: 300px; height: auto; margin-left: 20px; object-fit: cover;" >
            </div>
            <div class="col-lg-7 pt-3" >
                <h3 class="larger_text"><?php echo e($module->title); ?></h1>
                    <p class="text-muted pt-3">
                        <?php echo e(\Carbon\Carbon::parse($module->published_date)->format('d M Y') . ' | ' . $module->writer->name . ''); ?></p>
                    <p class="larger_text text-truncate">
                        <?php echo e($module->short_description); ?>

                    </p>
                    <a href="<?php echo e(route('module', $module->slug)); ?>" class="btn btn-dark px-5 rounded-5 float-end" style="border-radius: 60px;">Read more...</a>
              </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>







  
<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\UTS-2602089793\resources\views/home.blade.php ENDPATH**/ ?>