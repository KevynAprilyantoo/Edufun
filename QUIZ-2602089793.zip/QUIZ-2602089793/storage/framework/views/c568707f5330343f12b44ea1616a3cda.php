

<?php $__env->startSection('title'); ?>
<title>Writer</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="flex-grow-1">
    <div class="container-fluid pt-4">
        <h1>Our Writers:</h1>
    </div>

    <div class="container-fluid">
        <div class="row py-2 g-5 m-0 text-center">
            <?php $__empty_1 = true; $__currentLoopData = $writers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $writer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4 d-flex flex-column align-items-center justify-content-center">
                    <img src="<?php echo e(asset($writer->image)); ?>" alt="content" class="img-fluid w-50 mb-2 rounded-circle">
                    <a href="<?php echo e(route('writerdetail', $writer->id)); ?>" class="text-decoration-none text-dark">
                        <p class="mb-0 fw-bold"><?php echo e($writer->name); ?></p>
                        <p>Spesialis <?php echo e($writer->posts->first()->category->name); ?></p>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-center">No authors yet</p>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\UTS-2602089793\resources\views/writer.blade.php ENDPATH**/ ?>