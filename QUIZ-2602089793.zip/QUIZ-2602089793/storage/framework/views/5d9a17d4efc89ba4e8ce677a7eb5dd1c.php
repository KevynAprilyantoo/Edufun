

<?php $__env->startSection('title'); ?>
<title>Writer Detail</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="main flex-grow-1">
    <div class="container-fluid pt-4 d-flex gap-3">
        <img src="<?php echo e(asset($writer->image)); ?>" alt="content" class="img-fluid object-fit-cover mb-2 rounded-circle" style="width: 10%">
        <a href="<?php echo e(route('writer')); ?>" class="text-center d-flex flex-column justify-content-between py-3 text-decoration-none text-dark">
                <h3><?php echo e($writer->name); ?></h3>
                <p class="">Spesialis <?php echo e($writer->posts->first()->category->name); ?></p>
        </a>
    </div>

    <div class="container-fluid">
        <div class="row py-2 g-5 m-0">
            <?php $__currentLoopData = $writer->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 p-0">
                        <img src="<?php echo e(asset($module->thumbnail)); ?>" alt="content" class="img-fluid w-100" style="border-radius: 60px; max-height: 300px; height: auto; margin-left: 20px; object-fit: cover; " >
                    </div>
                    <div class="col-lg-8" style="padding-left = 10px">
                        <h3 class="larger_text"><?php echo e($module->title); ?></h1>
                            <p class="text-muted">
                                <?php echo e(\Carbon\Carbon::parse($module->published_date)->format('d M Y') . ' | ' . $module->writer->name . ''); ?></p>
                            <p class="larger_text text-truncate"  style="display: -webkit-box; -webkit-box-orient: vertical; overflow: hidden; text-overflow: ellipsis;">
                                <?php echo e($module->short_description); ?>

                            </p>
                            <a href="<?php echo e(route('post.show', $module->slug)); ?>" class="btn btn-dark px-5 rounded-5 float-end" style="border-radius: 40px;">Read more...</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\UTS-2602089793\resources\views/writerdetail.blade.php ENDPATH**/ ?>