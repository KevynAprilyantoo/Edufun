<footer class="footer p-3 mt-5" style="background-color: black">
    <div class="container">
        <p class="text-center text-white">
            © EduFun 2024 | Web Programming | Kevyn Aprilyanto | 2602089793
        </p>
    </div>
</footer>